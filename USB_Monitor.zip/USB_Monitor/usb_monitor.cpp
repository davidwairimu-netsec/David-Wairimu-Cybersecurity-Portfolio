#include <windows.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>
#include <ctime>
#include <dbt.h>
#include <cctype>
#include <algorithm>
#include <sstream>

// ============================================================
//   USB Flash Disk Intrusion Detection System v2.2
//   Fixed: Proper device notification registration
// ============================================================

const std::string LOG_FILE    = "usb_access_log.txt";
const std::string REPORT_FILE = "USB_Security_Report.txt";

// ── Utilities ────────────────────────────────────────────────

std::string getTimestamp() {
    time_t now = time(nullptr);
    char buf[64];
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &timeinfo);
    return std::string(buf);
}

std::string getToday() {
    time_t now = time(nullptr);
    char buf[12];
    struct tm timeinfo;
    localtime_s(&timeinfo, &now);
    strftime(buf, sizeof(buf), "%Y-%m-%d", &timeinfo);
    return std::string(buf);
}

// ── Logging ──────────────────────────────────────────────────

void logEvent(const std::string& eventType, const std::string& message) {
    std::string entry = "[" + getTimestamp() + "] [" + eventType + "] " + message;
    std::cout << entry << std::endl;

    std::ofstream logFile(LOG_FILE, std::ios::app);
    if (logFile.is_open()) {
        logFile << entry << "\n";
        logFile.close();
    }
}

// ── Device Info ──────────────────────────────────────────────

std::string getDriveInfo(char driveLetter) {
    std::string path = std::string(1, driveLetter) + ":\\";
    char volumeName[256] = {0};
    char fileSystem[256] = {0};
    DWORD serialNumber   = 0;
    DWORD maxCompLen     = 0;
    DWORD fileSystemFlags = 0;

    if (GetVolumeInformationA(
            path.c_str(),
            volumeName, sizeof(volumeName),
            &serialNumber, &maxCompLen, &fileSystemFlags,
            fileSystem, sizeof(fileSystem))) {
        std::stringstream ss;
        ss << "Label: [" << (volumeName[0] ? volumeName : "No Label") << "] "
           << "| Serial: " << serialNumber << " "
           << "| FS: " << fileSystem;
        return ss.str();
    }
    return "Unable to read drive info";
}

std::vector<std::string> listDriveRootEntries(const std::string& driveRoot) {
    std::vector<std::string> entries;
    std::string searchPath = driveRoot + "*";
    WIN32_FIND_DATAA findData;
    HANDLE hFind = FindFirstFileA(searchPath.c_str(), &findData);
    if (hFind == INVALID_HANDLE_VALUE) {
        return entries;
    }

    do {
        if (strcmp(findData.cFileName, ".") == 0 || strcmp(findData.cFileName, "..") == 0) {
            continue;
        }

        std::string item = driveRoot + findData.cFileName;
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            item += "\\";
        }
        entries.push_back(item);
    } while (FindNextFileA(hFind, &findData));

    FindClose(hFind);
    return entries;
}

bool hasTextExtension(const std::string& path) {
    const std::vector<std::string> extensions = {".txt", ".log", ".csv", ".ini", ".cfg", ".xml", ".json"};
    if (path.size() < 4) return false;

    std::string ext = path.substr(path.find_last_of('.'));
    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);

    for (const auto& validExt : extensions) {
        if (ext == validExt) return true;
    }
    return false;
}

std::string readFileSnippet(const std::string& filePath, size_t maxBytes = 1024) {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        return "Unable to open file for reading.";
    }

    std::string snippet;
    std::string line;
    while (std::getline(file, line)) {
        if (snippet.size() + line.size() + 1 > maxBytes) {
            snippet += "... (truncated)";
            break;
        }
        snippet += line + "\n";
    }
    return snippet.empty() ? "File is empty." : snippet;
}

void inspectUsbDrive(char driveLetter) {
    std::string driveRoot = std::string(1, driveLetter) + ":\\";
    auto entries = listDriveRootEntries(driveRoot);

    if (entries.empty()) {
        logEvent("INFO", "USB drive " + driveRoot + " is present but contains no root entries.");
        return;
    }

    std::string summary = "USB drive root contents for " + driveRoot + ":\n";
    size_t maxEntries = 25;
    for (size_t i = 0; i < entries.size() && i < maxEntries; ++i) {
        summary += "  " + entries[i] + "\n";
    }
    if (entries.size() > maxEntries) {
        summary += "  ... " + std::to_string(entries.size() - maxEntries) + " more entries ...\n";
    }
    logEvent("INFO", summary);

    size_t filesRead = 0;
    for (const auto& entry : entries) {
        if (!entry.empty() && entry.back() != '\\' && hasTextExtension(entry)) {
            std::string content = readFileSnippet(entry, 2048);
            logEvent("INFO", "Read from " + entry + ":\n" + content);
            filesRead++;
            if (filesRead >= 3) {
                logEvent("INFO", "Stopped reading after 3 files to avoid excessive logging.");
                break;
            }
        }
    }

    if (filesRead == 0) {
        logEvent("INFO", "No readable text files found on " + driveRoot + " to inspect.");
    }
}

// ── Daily Summary ─────────────────────────────────────────

void showDailySummary(HWND hwnd) {
    std::ifstream logFile(LOG_FILE);
    if (!logFile.is_open()) return;

    std::string today = getToday();
    std::string line;
    int alertCount = 0;
    std::string lastAlert;

    while (std::getline(logFile, line)) {
        if (line.find(today) != std::string::npos &&
            line.find("[ALERT]") != std::string::npos) {
            alertCount++;
            lastAlert = line;
        }
    }
    logFile.close();

    if (alertCount > 0) {
        std::string msg =
            "WARNING: " + std::to_string(alertCount) +
            " USB insertion(s) detected today!\n\n"
            "Last recorded attempt:\n" + lastAlert +
            "\n\nOpen '" + LOG_FILE + "' for the full event log.\n"
            "A security report has been saved to '" + REPORT_FILE + "'.";
        MessageBoxA(hwnd, msg.c_str(),
                    "USB SECURITY SUMMARY", MB_OK | MB_ICONWARNING | MB_TOPMOST);
    }
}

// ── On-Demand Security Report ─────────────────────────────────

void generateReport() {
    std::ifstream logFile(LOG_FILE);
    if (!logFile.is_open()) {
        // Create empty log file if it doesn't exist
        std::ofstream newLog(LOG_FILE);
        newLog.close();
        return;
    }

    std::string line;
    int total = 0, alerts = 0, removals = 0;
    std::string allLines;

    while (std::getline(logFile, line)) {
        allLines += line + "\n";
        total++;
        if (line.find("[ALERT]") != std::string::npos) alerts++;
        if (line.find("[REMOVAL]") != std::string::npos) removals++;
    }
    logFile.close();

    std::ofstream report(REPORT_FILE);
    if (!report.is_open()) return;

    report << "========================================\n";
    report << "       USB SECURITY INCIDENT REPORT     \n";
    report << "========================================\n";
    report << "Generated : " << getTimestamp() << "\n";
    report << "Log File  : " << LOG_FILE << "\n";
    report << "----------------------------------------\n";
    report << "SUMMARY\n";
    report << "  Total Events      : " << total << "\n";
    report << "  Insertion Alerts  : " << alerts << "\n";
    report << "  Removal Events    : " << removals << "\n";
    report << "----------------------------------------\n";
    report << "FULL EVENT LOG\n\n";
    report << allLines;
    report << "========================================\n";
    report << "END OF REPORT\n";
    report.close();
}

// ── Window Procedure ──────────────────────────────────────────

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DEVICECHANGE: {
            if (wParam == DBT_DEVICEARRIVAL) {
                PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)lParam;
                if (pHdr && pHdr->dbch_devicetype == DBT_DEVTYP_VOLUME) {
                    PDEV_BROADCAST_VOLUME pVol = (PDEV_BROADCAST_VOLUME)pHdr;
                    if (pVol->dbcv_unitmask == 0) break;

                    DWORD tempMask = pVol->dbcv_unitmask;
                    for (char drive = 'A'; drive <= 'Z'; drive++) {
                        if (tempMask & 1) {
                            std::string drivePath = std::string(1, drive) + ":\\";
                            UINT driveType = GetDriveTypeA(drivePath.c_str());

                            if (driveType == DRIVE_REMOVABLE) {
                                std::string info = getDriveInfo(drive);
                                std::string msg = "USB INSERTION DETECTED on Drive " +
                                                 std::string(1, drive) + ": | " + info;

                                logEvent("ALERT", msg);
                                inspectUsbDrive(drive);
                                generateReport();
                                LockWorkStation();

                                std::string popupMsg =
                                    "UNAUTHORIZED USB DEVICE DETECTED\n\n"
                                    "Drive  : " + std::string(1, drive) + ":\\\n"
                                    "Info   : " + info + "\n"
                                    "Time   : " + getTimestamp() + "\n\n"
                                    "The workstation was locked automatically.\n"
                                    "Full log saved to: " + LOG_FILE;

                                MessageBoxA(hwnd, popupMsg.c_str(),
                                            "USB SECURITY ALERT",
                                            MB_OK | MB_ICONWARNING | MB_TOPMOST);
                            }
                        }
                        tempMask >>= 1;
                    }
                }
            }
            else if (wParam == DBT_DEVICEREMOVECOMPLETE) {
                PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)lParam;
                if (pHdr && pHdr->dbch_devicetype == DBT_DEVTYP_VOLUME) {
                    PDEV_BROADCAST_VOLUME pVol = (PDEV_BROADCAST_VOLUME)pHdr;
                    if (pVol->dbcv_unitmask == 0) break;

                    DWORD tempMask = pVol->dbcv_unitmask;
                    for (char drive = 'A'; drive <= 'Z'; drive++) {
                        if (tempMask & 1) {
                            std::string drivePath = std::string(1, drive) + ":\\";
                            UINT driveType = GetDriveTypeA(drivePath.c_str());

                            if (driveType == DRIVE_REMOVABLE) {
                                logEvent("REMOVAL",
                                    "USB Drive " + std::string(1, drive) +
                                    ": was REMOVED from system.");
                                generateReport();
                            }
                        }
                        tempMask >>= 1;
                    }
                }
            }
            break;
        }

        case WM_QUERYENDSESSION:
        case WM_ENDSESSION: {
            logEvent("SYSTEM", "System shutting down, USB Monitor stopping.");
            return uMsg == WM_QUERYENDSESSION ? TRUE : DefWindowProc(hwnd, uMsg, wParam, lParam);
        }

        case WM_DESTROY: {
            PostQuitMessage(0);
            return 0;
        }
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

// ── Main ──────────────────────────────────────────────────────

int main() {
    SetConsoleOutputCP(CP_UTF8);

    std::cout << "============================================\n";
    std::cout << "   USB Intrusion Detection System v2.2     \n";
    std::cout << "============================================\n";
    std::cout << "Status  : ACTIVE - Monitoring USB ports...\n";
    std::cout << "Log     : " << LOG_FILE << "\n";
    std::cout << "Report  : " << REPORT_FILE << "\n";
    std::cout << "Press Ctrl+C to stop.\n\n";

    logEvent("SYSTEM", "USB Monitor STARTED. System is now being monitored.");

    // Register window class
    WNDCLASSA wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = "USBMonitorClass";

    if (!RegisterClassA(&wc)) {
        std::cerr << "ERROR: Failed to register window class. Error: " << GetLastError() << "\n";
        return 1;
    }

    // Create hidden window
    HWND hwnd = CreateWindowExA(
        0, "USBMonitorClass", "USB Monitor",
        0, 0, 0, 0, 0,
        HWND_MESSAGE, nullptr,
        GetModuleHandle(nullptr), nullptr
    );

    if (!hwnd) {
        std::cerr << "ERROR: Failed to create message window. Error: " << GetLastError() << "\n";
        return 1;
    }

    // CRITICAL: Register for device notifications
    DEV_BROADCAST_DEVICEINTERFACE_A notificationFilter = {};
    notificationFilter.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE_A);
    notificationFilter.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
    // Use GUID for USB devices
    // {A5DCBF10-6530-11D2-901F-00C04FB951ED} - GUID_DEVINTERFACE_VOLUME
    // Actually we want to use the volume interface
    // For simplicity, we'll use the device interface for all devices
    notificationFilter.dbcc_classguid = GUID_DEVINTERFACE_VOLUME;

    HDEVNOTIFY hDevNotify = RegisterDeviceNotificationA(
        hwnd,
        &notificationFilter,
        DEVICE_NOTIFY_WINDOW_HANDLE
    );

    if (!hDevNotify) {
        std::cerr << "WARNING: Failed to register for device notifications. Error: " << GetLastError() << "\n";
        std::cerr << "USB detection may not work properly.\n";
    } else {
        std::cout << "Device notifications registered successfully.\n";
    }

    // Show daily summary
    showDailySummary(hwnd);
    generateReport();

    // Main message loop
    MSG msg;
    BOOL bRet;
    while ((bRet = GetMessage(&msg, nullptr, 0, 0)) != 0) {
        if (bRet == -1) {
            std::cerr << "ERROR: GetMessage failed. Error: " << GetLastError() << "\n";
            break;
        }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    if (hDevNotify) {
        UnregisterDeviceNotification(hDevNotify);
    }
    logEvent("SYSTEM", "USB Monitor STOPPED.");
    generateReport();
    DestroyWindow(hwnd);
    UnregisterClassA("USBMonitorClass", GetModuleHandle(nullptr));

    std::cout << "\nUSB Monitor stopped successfully.\n";
    return 0;
}
